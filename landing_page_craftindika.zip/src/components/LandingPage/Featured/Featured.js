import React from 'react';
import "./featured.css";

// Images import
import featured_image1 from "../../../images/LandingPage/Featured/featured_image1.png";
import featured_image2 from "../../../images/LandingPage/Featured/featured_image2.png";

// Swiper import
import { Swiper, SwiperSlide } from "swiper/react";

// Import Swiper styles
import "swiper/css";
import "swiper/css/pagination";

// import required modules
import { Pagination, Navigation } from "swiper";

const Featured = () => {
    return (
        <div className='featured'>
            <div className='featured_header'>
                <div className='featured_header_left'>
                    <p>FEATURED</p>
                    <div>
                        <h3>Discover Our</h3>
                        <h3>Curated Collection</h3>
                    </div>
                </div>
                <div className='featured_header_right'>
                    <div>
                        <p>Embrace the distinctive elegance of our artisanal collection and</p>
                        <p>discover the timeless allure of India's finest handicrafts.</p>
                    </div>
                    <a href="#">Explore All Products</a>
                </div>
            </div>
            <div className='featured_carousel'>
                <Swiper
                    slidesPerView={2}
                    spaceBetween={30}
                    navigation={true}
                    pagination={{
                        clickable: true,
                    }}
                    modules={[Navigation]}
                    className="mySwiper"
                >
                    <div className='featured_carousel_single_main'>
                        <SwiperSlide>
                            <div className='featured_carousel_single'>
                                <img src={featured_image1} />
                                <div className='featured_carousel_single_info'>
                                    <h2>Metal Figurines</h2>
                                    <h3><span>over</span> 250 pieces</h3>
                                    <p>Made using Dhokra Metal Crafts, handcrafted in Rajasthan</p>
                                </div>
                            </div>
                        </SwiperSlide>
                    </div>
                    <div className='featured_carousel_single_main'>
                        <SwiperSlide>
                            <div className='featured_carousel_single'>
                                <img src={featured_image2} />
                                <div className='featured_carousel_single_info'>
                                    <h2>Chandua Artwork</h2>
                                    <h3><span>over</span> 435 styles</h3>
                                    <p>Indian appliqué craft, handcrafted and designed in Odisha</p>
                                </div>
                            </div>
                        </SwiperSlide>
                    </div>
                    <div className='featured_carousel_single_main'>
                        <SwiperSlide>
                            <div className='featured_carousel_single'>
                                <img src={featured_image2} />
                                <div className='featured_carousel_single_info'>
                                    <h2>Chandua Artwork</h2>
                                    <h3><span>over</span> 435 styles</h3>
                                    <p>Indian appliqué craft, handcrafted and designed in Odisha</p>
                                </div>
                            </div>
                        </SwiperSlide>
                    </div>

                </Swiper>


            </div>
        </div>
    )
}

export default Featured