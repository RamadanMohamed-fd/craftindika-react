import React, { useEffect, useState } from 'react';
import "./testimonials.css"

// Icons import
import {GoQuote} from "react-icons/go"

const Testimonials = () => {
    const [currTestimonial, setCurrTestimonial] = useState(0);

    const testimonialsData = [
        {
            userFeedback: "“Absolutely delighted with the exquisite Dhokra Metal creation I acquired from CraftIndika”",
            userImage: "https://images.unsplash.com/photo-1517940310602-26535839fe84?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2070&q=80",
            userName: "Bruce Mars",
            userProfile: "Customer"
        },
        {
            userFeedback: "““I noticed I asked you for a deliverable on this key project by the end of last week. I still”",
            userImage: "https://images.unsplash.com/photo-1613309440822-38f3fb0d5477?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
            userName: "Jordan Whitefield",
            userProfile: "Customer"
        },
        {
            userFeedback: "“Absolutely delighted with the exquisite Dhokra Metal creation I acquired from CraftIndika”",
            userImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
            userName: "Cristopher Cambell",
            userProfile: "Customer"
        },
        {
            userFeedback: "““I noticed I asked you for a deliverable on this key project by the end of last week. I stillthis deliverable and wanted to follow up.”",
            userImage: "https://images.unsplash.com/photo-1513673054901-2b5f51551112?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
            userName: "Tamara Bellis",
            userProfile: "Customer"
        }
    ]

    useEffect(() => {
        const timeOut = setTimeout(() => {
          setCurrTestimonial((currTestimonial + 1) % 4)
        }, 4000)
    
        return () => clearTimeout(timeOut)
      }, [currTestimonial])

  return (
    <div className='testimonials'>
        <div className='testimonials_quoteicon'>
            <GoQuote/>
        </div>
        <div className='testimonials_feedback'>
            {testimonialsData[currTestimonial].userFeedback}
        </div>
        <div className='testimonials_userdetails'>
            <img src = {testimonialsData[currTestimonial].userImage}/>
            <div className='testimonials_userDetails_right'>
                <p>{testimonialsData[currTestimonial].userName}</p>
                <p>{testimonialsData[currTestimonial].userProfile}</p>
            </div>
        </div>
        <div className='testimonials_pagination'>
            {
                testimonialsData.map((data, i) => (
                    <p  onClick={() =>
                        setCurrTestimonial((currTestimonial) => (currTestimonial + 1) % currTestimonial.length)
                      } className={i === currTestimonial ? "testimonials_pagination_active" : "testimonials_pagination_notactive"}>{i + 1}</p>
                ))
            }
        </div>
    </div>
  )
}

export default Testimonials