import React from 'react';
import "./showcase.css"

// Images import
import showcase_image1 from "../../../images/LandingPage/Showcase/showcase_image1.png";
import showcase_image2 from "../../../images/LandingPage/Showcase/showcase_image2.png";
import showcase_image3 from "../../../images/LandingPage/Showcase/showcase_image3.png";

// Swiper import
import { Swiper, SwiperSlide } from "swiper/react";

// Import Swiper styles
import "swiper/css";
import "swiper/css/pagination";

// import required modules
import { Pagination, Navigation } from "swiper";

const Showcase = () => {
  return (
    <div className='showcase'>
            <div className='showcase_header'>
                <div className='showcase_header_left'>
                    <p>SHOWCASE</p>
                    <div>
                        <h3>Setting CraftIndika Apart</h3>
                    </div>
                </div>
                <div className='showcase_header_right'>
                    <a href="#">Explore All Products</a>
                </div>
            </div>
            <div className='showcase_carousel'>
                <Swiper
                    slidesPerView={3}
                    spaceBetween={30}
                    navigation={true}
                    pagination={{
                        clickable: true,
                    }}
                    modules={[Navigation]}
                    className="mySwiper"
                >
                    <div className='showcase_carousel_single_main'>
                        <SwiperSlide>
                            <div className='showcase_carousel_single'>
                                <img src={showcase_image1} />
                                <div className='showcase_carousel_single_info'>
                                    <p>TRIBAL JEWELLERY</p>
                                    <h3>Classically imperfect statement</h3>
                                    <h3>jewellery for unique</h3>
                                    <h3>statement</h3>
                                </div>
                            </div>
                        </SwiperSlide>
                    </div>
                    <div className='showcase_carousel_single_main'>
                        <SwiperSlide>
                            <div className='showcase_carousel_single'>
                                <img src={showcase_image2} />
                                <div className='showcase_carousel_single_info'>
                                    <p>METAL CRAFTS</p>
                                    <h3>Revamp Your Space with</h3>
                                    <h3>the Alluring Charm of</h3>
                                    <h3>Bronze Decoratives</h3>
                                </div>
                            </div>
                        </SwiperSlide>
                    </div>
                    <div className='showcase_carousel_single_main'>
                        <SwiperSlide>
                            <div className='showcase_carousel_single'>
                                <img src={showcase_image3} />
                                <div className='showcase_carousel_single_info'>
                                    <p>GIFTING COLLECTION</p>
                                    <h3>Handpicked Luxury</h3>
                                    <h3>Treasures For Every</h3>
                                    <h3>Occasion</h3>
                                </div>
                            </div>
                        </SwiperSlide>
                    </div>
                    <div className='showcase_carousel_single_main'>
                        <SwiperSlide>
                            <div className='showcase_carousel_single'>
                                <img src={showcase_image3} />
                                <div className='showcase_carousel_single_info'>
                                    <p>GIFTING COLLECTION</p>
                                    <h3>Handpicked Luxury</h3>
                                    <h3>Treasures For Every</h3>
                                    <h3>Occasion</h3>
                                </div>
                            </div>
                        </SwiperSlide>
                    </div>

                </Swiper>
            </div>
        </div>
  )
}

export default Showcase