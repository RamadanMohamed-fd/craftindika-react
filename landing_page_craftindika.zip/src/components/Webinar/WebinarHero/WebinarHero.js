import React from 'react'
import "./webinarhero.css";

const WebinarHero = () => {
    return (
        <div className='webinar_hero'>
            <nav className='webinar_hero_nav'>
                <div className='webinar_hero_nav_logo'>
                    <h3>CRAFTINDIKA</h3>
                </div>
                <ul>
                    <li>Company</li>
                    <li>Collections</li>
                    <li>Curations</li>
                    <li>CraftPartner</li>
                    <li>Connect</li>
                </ul>
            </nav>
            <div className='webinar_hero_content'>
                <h4>ONLINE WEBINAR</h4>
                <div className='webinar_hero_content_heading'>
                    <h1>HANDCRAFT</h1>
                    <h1>your own business</h1>
                    <h1>WITH CRAFTS</h1>
                </div>
                <div>
                    <p>Discover the Secrets to Building a Profitable Handicraft Business that</p>
                    <p>Supports Indigenous Art and Promotes Cultural Diversity</p>
                </div>
            </div>
        </div>
    )
}

export default WebinarHero